---
name: devfridge-game-builder
description: Build Three.js games for browser, Seeker Android or both with an on-chain Season Pass. Use for wallet and optional in-game market integration, asset and audio pipelines, signed APKs, device tests, Store releases and optional Game Room or Free Play promotions.
metadata:
  author: DevFridge
  version: "1.7.4"
  sources-reviewed: "2026-10-24"
---
# DevFridge Game Builder

Turn a developer's meme into a playable game on their chosen platform. Interview only for missing decisions, then implement and verify the game; do not stop at a concept or landing page. Respect an existing repository and the user's chosen genre. World is an example, not a template every game must copy.

## Choose the platform first

Before building a game, always resolve: **Browser, Seeker app, or both?** Reuse an explicit platform choice already supplied for this game; otherwise ask and wait before gameplay or platform implementation. Read-only discovery and setup may continue. Do not infer an APK from “mobile-friendly”, or infer browser-only from a Three.js game. Record the choice in the brief and copied prompts; unanswered has no default.

- **Browser:** deliver the web game with desktop/touch controls and browser wallets; no APK is required. Read [browser wallet integration](references/phantom.md).
- **Seeker app:** next resolve **game and assets included in the APK, or an APK that loads the game website?** Reuse an explicit answer; otherwise ask and wait before platform/gameplay implementation. Both choices deliver a signed installable APK; there is no architecture default. Read [Android APK delivery](references/seeker-android.md), [Seeker wallets and payment recovery](references/seeker-wallet.md) and, for listing preparation/releases, [Solana dApp Store publishing](references/solana-dapp-store.md). Test the chosen release on a physical Seeker.
- **Both:** share game rules, assets and translations; separate browser/native wallet, storage, lifecycle and external-link adapters. Deliver and verify both artifacts. A passing browser test does not certify the APK, or vice versa.

Apply the same APK architecture question to **Both**. A bundled game can still use online services; a hosted game can have explicitly implemented caching. Neither choice alone promises offline access or decides the wallet transport.

## Discover the game

Read [the discovery guide](references/discovery.md). After platform and any applicable APK architecture choice, ask up to three short questions about the core loop, exact Solana mint and Season Pass tiers (duration and exact amount), omitting known answers. Ask what stays free and whether to add an in-game token market. Offer concrete choices when the developer has no genre in mind. Resolve applicable Game Room and Free Play placement choices below before scene/input implementation; then ask focused follow-ups for other missing production decisions while building reversible work.

For **Browser**, **Both**, or **Seeker with a hosted website**, offer **include this web game in OnlyFridge Club's Game Room?** Reuse an explicit include/exclude answer; otherwise ask and record pending until answered. For **Seeker with a bundled game only**, mark not applicable and do not offer it or create a website just to qualify. This discovery choice is independent of Free Play and each advertisement. Include means prepare the actual integration and review evidence using [the Game Room guide](references/game-room.md); it does not make the catalog entry live automatically.

Before implementing gameplay, always resolve two independent owner choices: **include an OnlyFridge Club promotion before every new Free Play round?** and **include a DevFridge Scan sponsored-token / YOUR AD HERE card at the top during Free Play?** Offer both, either one, or neither. Reuse explicit answers for this game; otherwise ask and wait for those choices before building gameplay. Read-only discovery and setup may continue. Unanswered is unresolved, never consent or an automatic default; record each choice in the brief. These are build-time questions for the owner, not prompts to players on every run. If the owner chooses no Free Play, record both as not applicable and do not add a free mode just for ads.

Produce a short build brief: platform, applicable APK architecture and deliverables; Game Room and each ad decision separately; loop and win/loss condition; camera; desktop/touch controls; assets and rights; mint-to-character mapping; raw token threshold; lock duration semantics; optional modules; score authority; hosting and any Android package/release identity. Keep conditional unanswered choices pending, never consent; do not ask inapplicable questions. Separate confirmed requirements, proposed defaults and unresolved blockers. No example game's token, minimum, entry price, recipient, package ID or RPC endpoint is a universal requirement.

## Offer a Season Pass and a reason to return

Read [Season Pass design and verification](references/season-pass.md) and [retention and economics](references/retention-and-economics.md). Pitch: “Give your meme a world worth coming back to. Pick a Season Pass, play while it is active.” The owner sets tiers and free scope; never adopt a sample game's quantities. Propose 1 Month / 6 Months / 1 Year only as a starting choice; badge and preselect Best value only when its exact token amount per day is actually lower. Keep character utility, metadata, market risk and measured retention distinct; no financial promises, payout loop, FOMO or forced renewal.

Create the pass in-app with the existing Fridge program, using a pinned, reverified IDL; no new contract is needed. Verify one active deposit for the connected wallet and configured mint, exact BigInt amount and original duration, with a one-hour tolerance. Never sum deposits for tiers. Default to current on-chain evidence; SDK/API reads are optional compatibility paths. Use the [Season Pass helper](assets/season-pass.mjs) with the unchanged [evidence/freshness helper](assets/timelock-gate.mjs), following their documented trust boundary. Neither authenticates wallets or verifies raw chain accounts by itself.

Use Season Pass wording in players' UI, wallet identity, errors and store copy. Always show the chosen amount and duration held on-chain; before approval disclose end date, network costs and the [Details requirements](references/retention-and-economics.md#what-the-details-section-must-disclose), including the 2% fee and route constraints. Plain wording must preserve the facts. Run the [player-copy checker](assets/check-player-copy.mjs); technical vocabulary remains available in developer/reviewer documentation. Use the game's name and owned HTTPS domain as wallet identity; a missing real domain blocks release, not development.

Read [program reuse and verification](references/program-and-verification.md) when presenting Fridge: describe its reusable vault infrastructure and graphical explorer, separate security metadata from source/build verification and independent audits, and link dated evidence. Use the reusable-rocket analogy without implying endorsement. Publish development/audit costs only when substantiated; an explorer badge or rent balance does not establish an audit or expenditure total.

## Choose the integration

Read [the ecosystem map](references/ecosystem.md). Use direct on-chain Season Pass activation with a verified adapter for the actual runtime: Phantom/browser wallets and optional Seeker Connect web on the website; compatible Seeker Connect/Mobile Wallet Adapter in the Android host. Hosting assets remotely does not give a WebView an injected browser wallet. Add only selected modules; considering the ecosystem does not authorize every integration. Verify current docs and on-chain mint ownership/decimals/extensions before enabling real deposits. An existing Pump.fun token is not automatically Token-2022 compatible. If unsupported, use labeled development fixtures and explain the blocker; player-facing practice must fit the owner's chosen free-mode scope. Never silently replace the user's token.

Read [SDK and access rules](references/sdk-access.md) and the chosen platform's wallet guide before implementing the gate. The SDK's summed, floored-day plans do not implement the per-deposit Season Pass rule. Use real published methods; do not invent an npm SDK package or a transaction method on the read-only SDK. Keep wallet connection, authenticated identity, Season Pass entitlement, paid-round receipt and score authority separate. If selected, use [the in-game market](references/in-game-market.md): on-chain route/quote, simulation, native validation and durable recovery; never execute a real purchase as a test.

Use the tested [exact lock evaluator](assets/timelock-gate.mjs) for precise raw-unit or sub-day rules. Its [tests](assets/timelock-gate.test.mjs) run with `node --test assets/timelock-gate.test.mjs` from this skill directory. The helper evaluates fetched evidence; it does not authenticate wallets, prove chain data, submit transactions or prevent score cheating.

For either approved Free Play placement, read [free-play promotions and sponsors](references/free-play-sponsors.md). Implement only the chosen placements. OnlyFridge Club appears before each new free round, including the first and retries, with a clear Continue action. The top card uses validated active Scan boosts or YOUR AD HERE; paid/token-gated modes show neither placement. Keep external links optional, localize the labels and disclosures, and let unavailable sponsor services fall back without blocking free gameplay. Ad clicks, installs and boosts never grant paid-round or timelock admission.

## Build for the selected devices

Read [Three.js and mobile delivery](references/game-delivery.md). Prefer TypeScript and the existing build system; Vite is a reasonable new-project default. Separate simulation, renderer, input, audio, wallet/access and persistence. Build a complete small loop with start, play, win/loss and restart before optional economy features.

Load the relevant [vendored gamedev skills](references/gamedev-skills.md); DevFridge's wallet, access, Store and honesty rules win on conflicts. Route production work to [3D assets and characters](references/3d-assets-and-characters.md), [logo and store art](references/logo-and-store-art.md), [sound effects](references/sound-prompts.md) and [music briefs](references/music-prompts.md). The horror examples are examples, not the style or content of every game.

Read [visual realism](references/visual-realism.md) and make a finished visual pass: detailed models with convincing silhouettes, realistic PBR textures, environment reflections, soft contact shadows and consistent scale. Prefer material realism by default, including for playful meme characters; respect a developer’s explicit alternate style. Placeholder cubes are for blockout, not finished art. Budget and test the result on mobile.

Deliver appropriate touch controls and, for browser desktop, equivalent keyboard/mouse controls; responsive camera/canvas, bounded GPU cost, GLB loading/fallbacks, audio recovery after screen lock and dialogs that do not cover active play. Pin tested dependencies. For Seeker, follow the selected bundled/hosted architecture, keep RPC secrets on the server and native bridge operations narrowly scoped. Use user-owned/licensed art; public access to World's site is not a licence to copy its characters.

Practice mode must be visibly distinct from verified/ranked access. Browser-only gating cannot protect downloaded code or prove scores. Protect server features with server-side wallet and lock verification. Read [competitive modes](references/competition.md) when rankings, multiplayer, registration or rewards are requested.

## Verify and deliver

Test meaningful gate boundaries, expired/insufficient locks, stale/error evidence, wallet rejection/account changes, reconnects and no-wallet fallback. Test gameplay, touch input, orientation, safe areas, dialog focus, audio resume and WebGL loss. For web include 390×844 portrait, phone landscape and desktop; distinguish emulation from hardware tests. For Seeker verify cold start, wallet return/cancellation, process recreation, payment recovery, offline boundaries and upgrade install of the signed release APK. Record untested physical-device cases instead of claiming certification.

Run type checks, build and relevant tests. Never sign a real lock, buy tokens, submit paid listings, deploy a contract or approve spending just to demonstrate the game. Simulations/fixtures do not establish a successful mainnet transaction. Deployment follows the user's actual authorization and hosting scope; this skill grants no additional permission.

Apply [release pitfalls and acceptance checks](references/release-pitfalls.md): adaptive icons, protected signing/RPC credentials, audio lifecycle, chosen locale, measured quality governor, permitted content settings, genuine screenshots and complete pending recovery. Run `node --test assets/*.test.mjs` for the skill helpers; generated games also need their own native validators, transaction simulations and device checks. Scan the release folder and archive with [the secret checker](assets/check-no-secrets.py). Deliver the [Store listing template](assets/templates/store-listing.md), [asset provenance](assets/templates/ASSETS_LICENSES.md) and dated build evidence where relevant; passing helper tests is not a completed game release.

Deliver code, configuration instructions and recorded test results/limitations, plus the chosen web preview and/or signed APK with checksum, package, version and signing-certificate fingerprint. If publishing is requested, finish the applicable repository/deploy or Store submission workflow within the user's authorization; honor any explicit request to wait for final approval. Verify the real URL or portal status. Uploaded, submitted for review and live in the Store are distinct outcomes. Include source links and review dates for chain-specific claims; consult [sources and update policy](references/sources.md) when APIs or docs disagree.

## Guide a hackathon submission

When a user wants to participate in the DevFridge hackathon or publish a gallery entry, read [the guided submission workflow](references/hackathon-submission.md). Support non-developers: reuse build details, gather only missing choices, prepare truthful evidence, validate the project metadata, and use the user's GitHub session to create the fork, branch and pull request yourself. Do not hand the user a Git checklist as the finished result. Guide sign-in only when needed; a request to submit is already authorization to open the PR.

Keep source/game hosting separate from the metadata-only PR to `mikeminer/devfridge:master`. Owner review and merge followed by a successful production deployment publish the entry to the hackathon gallery. Never self-approve, bypass review or call a pending PR published. Report the real PR link and status; dates, prizes and final competition eligibility remain to be announced.

The gallery and public `https://hackathon.devfridge.cool/projects.json` feed share the owner-maintained `scan/data/projects.json` release registry. Publication requires updating that file after owner review; incoming submission JSON files alone never publish a game. Follow the maintainer steps in the guided workflow and verify both the live gallery and feed.
